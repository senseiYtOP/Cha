import { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } from 'discord.js';
import sqlite3 from 'sqlite3';
import crypto from 'crypto';
import 'dotenv/config';

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.DirectMessages] });
const db = new sqlite3.Database('./users.db');

db.run(`CREATE TABLE IF NOT EXISTS users (
    discord_id TEXT PRIMARY KEY,
    username TEXT,
    password TEXT
)`);

const commands = [
    new SlashCommandBuilder()
        .setName('register')
        .setDescription('Create an account for the messaging website')
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

(async () => {
    try {
        await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
        console.log('🤖 Discord commands registered.');
    } catch (error) {
        console.error(error);
    }
})();

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'register') {
        const discordId = interaction.user.id;
        const username = interaction.user.username;

        db.get(`SELECT * FROM users WHERE discord_id = ?`, [discordId], async (err, row) => {
            if (row) return interaction.reply({ content: '❌ You already have an account!', ephemeral: true });

            const generatedPassword = crypto.randomBytes(4).toString('hex');

            db.run(`INSERT INTO users (discord_id, username, password) VALUES (?, ?, ?)`, 
                [discordId, username, generatedPassword], 
                async (err) => {
                    if (err) return interaction.reply({ content: '❌ Database error.', ephemeral: true });

                    try {
                        await interaction.user.send(
                            `🎉 **Website Account Created!**\n\n` +
                            `**User ID:** \`${discordId}\`\n` +
                            `**Password:** \`${generatedPassword}\``
                        );
                        await interaction.reply({ content: '📨 Check your DMs for details!', ephemeral: true });
                    } catch (dmErr) {
                        db.run(`DELETE FROM users WHERE discord_id = ?`, [discordId]);
                        await interaction.reply({ content: '❌ Open your DMs and try again.', ephemeral: true });
                    }
                }
            );
        });
    }
});

client.login(process.env.DISCORD_TOKEN);