import express from 'express';
import session from 'express-session';
import sqlite3 from 'sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const PORT = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new sqlite3.Database('./users.db');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({ secret: 'secret_key', resave: false, saveUninitialized: true }));

db.run(`CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    text TEXT
)`);

app.use(express.static(path.join(__dirname, 'public')));

app.post('/login', (req, res) => {
    const { discord_id, password } = req.body;
    db.get(`SELECT * FROM users WHERE discord_id = ? AND password = ?`, [discord_id, password], (err, user) => {
        if (!user) return res.send('<h2>Invalid Login. Go back and try again.</h2>');
        req.session.user = { username: user.username };
        res.redirect('/chat.html');
    });
});

app.get('/api/messages', (req, res) => {
    if (!req.session.user) return res.status(401).json([]);
    db.all(`SELECT username, text FROM messages ORDER BY id ASC LIMIT 50`, [], (err, rows) => {
        res.json(rows || []);
    });
});

app.post('/api/messages', (req, res) => {
    if (!req.session.user) return res.status(401).end();
    db.run(`INSERT INTO messages (username, text) VALUES (?, ?)`, [req.session.user.username, req.body.text], () => {
        res.json({ success: true });
    });
});

app.listen(PORT, () => console.log(`🌐 Web Server running on port ${PORT}`));